### RNASeq pipelines (bash scripts) for data alignment (`run_alignment`), gene quantification (`run_quantification`), gene differential analysis (`run_differential_test`).
