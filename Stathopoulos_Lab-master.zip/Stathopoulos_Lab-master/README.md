# Stathopoulos_Lab
[Opa manuscript](https://elifesciences.org/articles/59610) ChIP-Seq, ATAC-Seq, and RNA-Seq data processing pipelines.
