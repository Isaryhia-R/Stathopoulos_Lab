### This folder includes two bash scripts (`run_alignment`, `run_peaks`) for ChIPSeq data processing.
